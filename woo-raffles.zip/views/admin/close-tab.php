<script type="text/javascript">
    window.close();
</script>